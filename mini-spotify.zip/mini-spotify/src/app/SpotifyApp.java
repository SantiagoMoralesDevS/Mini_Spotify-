package app;

import modelo.BibliotecaMusical;
import modelo.Cancion;
import modelo.CuentaSpotify;
import modelo.Playlist;
import modelo.Reproducible;

import java.util.Scanner;



public class SpotifyApp {

    //--------------------------------------------------------------------------------------------------//
    // Scanner compartido para lectura de entradas del usuario
    //--------------------------------------------------------------------------------------------------//

    private static Scanner scanner = new Scanner(System.in);

    //--------------------------------------------------------------------------------------------------//
    // Referencia a la canción actualmente en reproducción (para poder detenerla)
    //--------------------------------------------------------------------------------------------------//

    private static Cancion cancionActual = null;

    public static void main(String[] args) {

        // =====================================================================
        // A. PREPARACIÓN ANTES DEL MENÚ
        // =====================================================================

        //----------------------------------------------------------------------------------------------------------//
        // Crear la biblioteca musical y cargar canciones de prueba
        //----------------------------------------------------------------------------------------------------------//
        BibliotecaMusical biblioteca = new BibliotecaMusical();
        biblioteca.agregarCancion(new Cancion("Shape of You", "Ed Sheeran", 240));
        biblioteca.agregarCancion(new Cancion("Believer", "Imagine Dragons", 210));
        biblioteca.agregarCancion(new Cancion("Thunderstruck", "AC/DC", 290));
        biblioteca.agregarCancion(new Cancion("Someone Like You", "Adele", 300));

        //----------------------------------------------------------------------------------------------------------//
        // Crear cuenta de usuario y asociar biblioteca
        //----------------------------------------------------------------------------------------------------------//

        CuentaSpotify cuenta = new CuentaSpotify("enrique", "1234");
        cuenta.setBiblioteca(biblioteca);

        // =====================================================================
        // B. MENÚ PRINCIPAL
        // =====================================================================

        boolean ejecutando = true;

        while (ejecutando) {
            mostrarMenuPrincipal();
            int opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    menuIniciarSesion(cuenta);
                    break;
                case 2:
                    if (!verificarSesion(cuenta)) break;
                    menuBiblioteca(cuenta.getBiblioteca());
                    break;
                case 3:
                    if (!verificarSesion(cuenta)) break;
                    menuPlaylists(cuenta);
                    break;
                case 4:
                    if (!verificarSesion(cuenta)) break;
                    menuReproduccion(cuenta);
                    break;
                case 5:
                    cuenta.cerrarSesion();
                    break;
                case 6:
                    System.out.println("\nGracias por usar Mini-Spotify. ¡Hasta pronto!");
                    ejecutando = false;
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }

        scanner.close();
    }

    // =========================================================================
    // MENÚ PRINCIPAL
    // =========================================================================

    /**--------------------------------------------------------------------------------------------------//
     * Imprime el menú principal en consola.
     *////--------------------------------------------------------------------------------------------------//
    private static void mostrarMenuPrincipal() {
        System.out.println("\n=== MINI-SPOTIFY ===");
        System.out.println("1. Iniciar sesión");
        System.out.println("2. Gestionar Biblioteca Musical");
        System.out.println("3. Gestionar Playlists");
        System.out.println("4. Reproducir Canciones");
        System.out.println("5. Cerrar sesión");
        System.out.println("6. Salir del programa");
    }

    // =========================================================================
    // SUBMENÚ 1: INICIAR SESIÓN
    // =========================================================================

    /**----------------------------------------------------------------------------------------------------------
     * Solicita credenciales e intenta iniciar sesión en la cuenta.
     *
     * @param cuenta Cuenta del usuario.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static void menuIniciarSesion(CuentaSpotify cuenta) {
        System.out.println("\n--- INICIAR SESIÓN ---");
        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();
        cuenta.iniciarSesion(usuario, contrasena);
    }

    // =========================================================================
    // SUBMENÚ 2: GESTIÓN DE BIBLIOTECA MUSICAL
    // =========================================================================

    /**----------------------------------------------------------------------------------------------------------
     * Muestra y gestiona el submenú de la biblioteca musical.
     *
     * @param biblioteca Biblioteca musical de la cuenta.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static void menuBiblioteca(BibliotecaMusical biblioteca) {
        boolean volver = false;

        while (!volver) {
            System.out.println("\n--- GESTIÓN DE BIBLIOTECA ---");
            System.out.println("1. Listar canciones");
            System.out.println("2. Agregar canción");
            System.out.println("3. Buscar por nombre");
            System.out.println("4. Volver");
            int opcion = leerEntero("Seleccione: ");

            switch (opcion) {
                case 1:

                //--------------------------------------------------------------------------------------------------//
                    // Listar todas las canciones del catálogo
                //--------------------------------------------------------------------------------------------------//

                    biblioteca.listarCatalogo();
                    esperarEnter();
                    break;
                case 2:
                
                //--------------------------------------------------------------------------------------------------//
                    // Agregar nueva canción ingresada por el usuario
                //--------------------------------------------------------------------------------------------------//

                    System.out.println("\n--- AGREGAR CANCIÓN ---");
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Artista: ");
                    String artista = scanner.nextLine();
                    int duracion = leerEntero("Duración en segundos: ");
                
                    //--------------------------------------------------------------------------------------------------//
                    // Uso de constructor sobrecargado de Cancion
                    //--------------------------------------------------------------------------------------------------//
                    biblioteca.agregarCancion(new Cancion(titulo, artista, duracion));
                    esperarEnter();
                    break;
                case 3:
                
                //--------------------------------------------------------------------------------------------------//
                    // Buscar canción por nombre o fragmento
                //--------------------------------------------------------------------------------------------------//

                    System.out.println("\n--- BUSCAR CANCIÓN ---");
                    System.out.print("Ingrese nombre o fragmento: ");
                    String fragmento = scanner.nextLine();
                    Cancion encontrada = biblioteca.buscarPorNombre(fragmento);
                    if (encontrada != null) {
                        System.out.println("Resultado encontrado:");
                        System.out.println(encontrada.getInfo());
                    } else {
                        System.out.println("No se encontró ninguna canción con ese nombre.");
                    }
                    esperarEnter();
                    break;
                case 4:
                    volver = true;
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    // =========================================================================
    // SUBMENÚ 3: GESTIÓN DE PLAYLISTS
    // =========================================================================

    /**----------------------------------------------------------------------------------------------------------
     * Muestra y gestiona el submenú de playlists del usuario.
     *
     * @param cuenta Cuenta del usuario.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static void menuPlaylists(CuentaSpotify cuenta) {
        boolean volver = false;

        while (!volver) {
            System.out.println("\n--- GESTIÓN DE PLAYLISTS ---");
            System.out.println("1. Crear playlist");
            System.out.println("2. Listar playlists");
            System.out.println("3. Agregar canción a playlist");
            System.out.println("4. Ver canciones de una playlist");
            System.out.println("5. Volver");
            int opcion = leerEntero("Seleccione: ");

            switch (opcion) {
                case 1:

            //--------------------------------------------------------------------------------------------------//
                    // Crear una nueva playlist
            //--------------------------------------------------------------------------------------------------//
                    System.out.println("\n--- CREAR PLAYLIST ---");
                    System.out.print("Ingrese nombre: ");
                    String nombrePlaylist = scanner.nextLine();
                    // Constructor sobrecargado de Playlist (sin especificar max)
                    cuenta.agregarPlaylist(new Playlist(nombrePlaylist));
                    esperarEnter();
                    break;
                case 2:

                //--------------------------------------------------------------------------------------------------//
                    // Listar todas las playlists del usuario
                //--------------------------------------------------------------------------------------------------//

                    System.out.println("\n--- MIS PLAYLISTS ---");
                    if (cuenta.getContadorPlaylists() == 0) {
                        System.out.println("No tienes playlists creadas.");
                    } else {
                        for (int i = 0; i < cuenta.getContadorPlaylists(); i++) {
                            System.out.println("[" + i + "] " + cuenta.getPlaylists()[i].getNombre()
                                    + " (" + cuenta.getPlaylists()[i].getContadorCanciones() + " canciones)");
                        }
                    }
                    esperarEnter();
                    break;
                case 3:

                //--------------------------------------------------------------------------------------------------//
                    // Agregar una canción de la biblioteca a una playlist
                //--------------------------------------------------------------------------------------------------//

                    menuAgregarCancionAPlaylist(cuenta);
                    esperarEnter();
                    break;
                case 4:
                
                //--------------------------------------------------------------------------------------------------//
                    // Ver las canciones de una playlist específica
                //--------------------------------------------------------------------------------------------------//

                    System.out.println("\n--- VER CANCIONES EN PLAYLIST ---");
                    System.out.print("Nombre de la playlist: ");
                    String nombre = scanner.nextLine();
                    Playlist pl = cuenta.buscarPlaylist(nombre);
                    if (pl == null) {
                        System.out.println("No se encontró la playlist.");
                    } else {
                        pl.listarCanciones();
                    }
                    esperarEnter();
                    break;
                case 5:
                    volver = true;
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    /**----------------------------------------------------------------------------------------------------------
     * Muestra el catálogo y permite seleccionar una canción para agregar a una playlist.
     *
     * @param cuenta Cuenta del usuario.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static void menuAgregarCancionAPlaylist(CuentaSpotify cuenta) {
        System.out.println("\n--- AGREGAR CANCIÓN A PLAYLIST ---");
        System.out.print("Nombre de la playlist: ");
        String nombrePlaylist = scanner.nextLine();

        //--------------------------------------------------------------------------------------------------//
        // Verificar que la playlist exista antes de continuar
        //--------------------------------------------------------------------------------------------------//

        Playlist pl = cuenta.buscarPlaylist(nombrePlaylist);
        if (pl == null) {
            System.out.println("No se encontró la playlist \"" + nombrePlaylist + "\".");
            return;
        }

        //--------------------------------------------------------------------------------------------------//
        // Mostrar el catálogo de canciones disponibles
        //--------------------------------------------------------------------------------------------------//
        System.out.println("Seleccione canción del catálogo:");
        BibliotecaMusical biblioteca = cuenta.getBiblioteca();

        if (biblioteca.getContadorCatalogo() == 0) {
            System.out.println("La biblioteca está vacía.");
            return;
        }

        System.out.println();
        for (int i = 0; i < biblioteca.getContadorCatalogo(); i++) {
            Cancion c = biblioteca.getCatalogo()[i];
            System.out.println("[" + i + "] " + c.getTitulo() + " - " + c.getArtista());
        }

        int indice = leerEntero("Ingrese índice de canción: ");
        if (indice < 0 || indice >= biblioteca.getContadorCatalogo()) {
            System.out.println("Índice inválido.");
            return;
        }

        //----------------------------------------------------------------------------------------------------------//
        // Agregar la canción seleccionada a la playlist
        //----------------------------------------------------------------------------------------------------------//
        Cancion seleccionada = biblioteca.getCatalogo()[indice];
        cuenta.agregarCancionAPlaylist(nombrePlaylist, seleccionada);
    }

    // =========================================================================
    // SUBMENÚ 4: REPRODUCCIÓN DE CANCIONES
    // =========================================================================

    /**----------------------------------------------------------------------------------------------------------
     * Muestra y gestiona el submenú de reproducción de canciones.
     * Hace uso explícito de la interfaz Reproducible y polimorfismo.
     *
     * @param cuenta Cuenta del usuario.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static void menuReproduccion(CuentaSpotify cuenta) {
        boolean volver = false;

        while (!volver) {
            System.out.println("\n--- REPRODUCCIÓN ---");
            System.out.println("1. Reproducir canción desde playlist");
            System.out.println("2. Detener reproducción");
            System.out.println("3. Volver");
            int opcion = leerEntero("Seleccione: ");

            switch (opcion) {
                case 1:

                //--------------------------------------------------------------------------------------------------//
                    // Reproducir una canción de una playlist específica
                //--------------------------------------------------------------------------------------------------//

                    System.out.println("\n--- REPRODUCIR DESDE PLAYLIST ---");
                    System.out.print("Nombre de la playlist: ");
                    String nombrePlaylist = scanner.nextLine();

                    Playlist pl = cuenta.buscarPlaylist(nombrePlaylist);
                    if (pl == null) {
                        System.out.println("No se encontró la playlist.");
                        break;
                    }

                    System.out.println("Canciones disponibles:");
                    pl.listarCanciones();

                    int indice = leerEntero("Ingrese índice de canción: ");

                    //--------------------------------------------------------------------------------------------------//
                    // Reproducción polimórfica usando la interfaz Reproducible
                    //--------------------------------------------------------------------------------------------------//

                    Cancion reproducida = cuenta.reproducir(nombrePlaylist, indice);
                    if (reproducida != null) {
                        cancionActual = reproducida; // Guardamos referencia para poder detenerla
                    }
                    esperarEnter();
                    break;
                case 2:
                    
                //--------------------------------------------------------------------------------------------------//
                    // Detener la canción actualmente en reproducción
                //--------------------------------------------------------------------------------------------------//

                    if (cancionActual != null) {

                        //----------------------------------------------------------------------------------------------------------//
                        // Uso polimórfico: Cancion como Reproducible
                        //----------------------------------------------------------------------------------------------------------//
                        Reproducible r = cancionActual;
                        r.detener();
                        cancionActual = null;
                    } else {
                        System.out.println("No hay ninguna canción en reproducción.");
                    }
                    break;
                case 3:
                    volver = true;
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    // =========================================================================
    // UTILIDADES
    // =========================================================================

    /**----------------------------------------------------------------------------------------------------------
     * Verifica si la sesión del usuario está activa.
     * Si no lo está, muestra un mensaje de advertencia.
     *
     * @param cuenta Cuenta del usuario.
     * @return true si la sesión está activa, false en caso contrario.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static boolean verificarSesion(CuentaSpotify cuenta) {
        if (!cuenta.isSesionIniciada()) {
            System.out.println("Debe iniciar sesión para acceder a esta opción.");
            return false;
        }
        return true;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Lee un número entero desde la consola, mostrando el mensaje indicado.
     * Maneja entradas inválidas sin detener el programa.
     *
     * @param mensaje Mensaje a mostrar antes de leer.
     * @return Entero ingresado por el usuario, o -1 si la entrada es inválida.
     * ----------------------------------------------------------------------------------------------------------
     */
    private static int leerEntero(String mensaje) {
        System.out.print(mensaje);
        int valor = -1;
        try {
            valor = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Se esperaba un número entero.");
        }
        return valor;
    }

    /**-----------------------------------------------------------------------------------------------------------
     * Pausa la ejecución hasta que el usuario presione ENTER.
     *///----------------------------------------------------------------------------------------------------------
    private static void esperarEnter() {
        System.out.print("\nPresione ENTER para continuar...");
        scanner.nextLine();
    }
}
