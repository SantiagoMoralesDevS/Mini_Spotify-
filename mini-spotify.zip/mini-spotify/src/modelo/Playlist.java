package modelo;


public class Playlist {

    private String nombre;
    private Cancion[] canciones;     // Arreglo de canciones de la playlist
    private int contadorCanciones;   // Número actual de canciones
    private int maxCanciones;        // Capacidad máxima

    /**----------------------------------------------------------------------------------------------------------
     * Constructor con nombre y capacidad máxima personalizada.
     *
     * @param nombre      Nombre de la playlist.
     * @param maxCanciones Número máximo de canciones que puede contener.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Playlist(String nombre, int maxCanciones) {
        this.nombre = nombre;
        this.maxCanciones = maxCanciones;
        this.canciones = new Cancion[maxCanciones];
        this.contadorCanciones = 0;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Constructor sobrecargado: asigna capacidad máxima por defecto (20 canciones).
     *
     * @param nombre Nombre de la playlist.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Playlist(String nombre) {
        this(nombre, 20); // Delega al constructor principal con capacidad 20
    }

    // ----------------------------- Getters --------------------------------------

    public String getNombre() {
        return nombre;
    }

    public int getContadorCanciones() {
        return contadorCanciones;
    }

    public Cancion[] getCanciones() {
        return canciones;
    }

    // ----------------------------- Métodos principales -------------------------

    /**----------------------------------------------------------------------------------------------------------
     * Agrega una canción ya instanciada a la playlist.
     *
     * @param c Objeto Cancion a agregar.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void agregarCancion(Cancion c) {
        if (estaLlena()) {
            System.out.println("La playlist \"" + nombre + "\" está llena. No se pudo agregar la canción.");
            return;
        }
        canciones[contadorCanciones] = c;
        contadorCanciones++;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Sobrecarga: agrega una canción creándola con sus datos básicos.
     *
     * @param titulo   Título de la nueva canción.
     * @param artista  Artista de la nueva canción.
     * @param duracion Duración en segundos de la nueva canción.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void agregarCancion(String titulo, String artista, int duracion) {
        Cancion nueva = new Cancion(titulo, artista, duracion);
        agregarCancion(nueva); // Reutiliza el método principal
    }

    /**----------------------------------------------------------------------------------------------------------
     * Lista todas las canciones de la playlist en consola.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void listarCanciones() {
        if (contadorCanciones == 0) {
            System.out.println("La playlist \"" + nombre + "\" está vacía.");
            return;
        }
        System.out.println("Playlist: " + nombre);
        for (int i = 0; i < contadorCanciones; i++) {
            System.out.println("[" + i + "] " + canciones[i].getInfo());
        }
        System.out.println("------------------------------------------");
        System.out.println("Total: " + contadorCanciones + (contadorCanciones == 1 ? " canción" : " canciones"));
    }

    /**----------------------------------------------------------------------------------------------------------
     * Reproduce una canción de la playlist según su índice.
     * Usa la interfaz Reproducible de forma polimórfica.
     *
     * @param index Índice de la canción a reproducir.
     * @return La canción reproducida, o null si el índice es inválido.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Cancion reproducirCancion(int index) {
        if (index < 0 || index >= contadorCanciones) {
            System.out.println("Índice inválido. No se encontró la canción.");
            return null;
        }
        // Uso polimórfico: Cancion implementa Reproducible
        Reproducible reproducible = canciones[index];
        reproducible.reproducir();
        return canciones[index];
    }

    /**----------------------------------------------------------------------------------------------------------
     * Verifica si la playlist ha alcanzado su capacidad máxima.
     *
     * @return true si está llena, false en caso contrario.
     * ----------------------------------------------------------------------------------------------------------
     */
    public boolean estaLlena() {
        return contadorCanciones >= maxCanciones;
    }
}
