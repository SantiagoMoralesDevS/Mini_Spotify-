package modelo;


public class Cancion extends Multimedia implements Reproducible {

    // Atributo propio de Cancion
    private String artista;

    /**----------------------------------------------------------------------------------------------------------
     * Constructor completo con título, artista y duración.
     *
     * @param titulo           Título de la canción.
     * @param artista          Artista o banda de la canción.
     * @param duracionSegundos Duración de la canción en segundos.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Cancion(String titulo, String artista, int duracionSegundos) {
        super(titulo, duracionSegundos); // Llama al constructor de Multimedia
        this.artista = artista;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Constructor sobrecargado: crea una canción sin duración definida.
     *
     * @param titulo  Título de la canción.
     * @param artista Artista o banda de la canción.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Cancion(String titulo, String artista) {
        super(titulo); // Usa el constructor sobrecargado de Multimedia
        this.artista = artista;
    }

    // ----------------------------- Getters y Setters -----------------------------

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    // ----------------------------- Métodos de Reproducible ----------------------

    /**----------------------------------------------------------------------------------------------------------
     * Implementación polimórfica de reproducir().
     * Muestra en consola que la canción está siendo reproducida.
     * ----------------------------------------------------------------------------------------------------------
     */
    @Override
    public void reproducir() {
        System.out.println("\nReproduciendo...");
        System.out.println("♪ " + titulo + " - " + artista + " (duración: " + duracionSegundos + "s)");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Implementación polimórfica de detener().
     * Informa que la reproducción ha sido detenida.
     * ----------------------------------------------------------------------------------------------------------
     */
    @Override
    public void detener() {
        System.out.println("Reproducción detenida.");
    }

    // ----------------------------- Métodos de Multimedia ------------------------

    /**----------------------------------------------------------------------------------------------------------
     * Retorna información descriptiva de la canción.
     *
     * @return Cadena con título, artista y duración.
     * ----------------------------------------------------------------------------------------------------------
     */
    @Override
    public String getInfo() {
        return titulo + " - " + artista + " (" + duracionSegundos + "s)";
    }

    /**----------------------------------------------------------------------------------------------------------
     * Representación en texto de la canción.
     *
     * @return Cadena formateada con título, artista y duración.
     * ----------------------------------------------------------------------------------------------------------
     */
    @Override
    public String toString() {
        return titulo + " - " + artista + " (" + duracionSegundos + "s)";
    }
}
