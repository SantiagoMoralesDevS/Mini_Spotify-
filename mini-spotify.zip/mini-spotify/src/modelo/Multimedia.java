package modelo;


public abstract class Multimedia {

    // Atributos protegidos accesibles por las subclases
    protected String titulo;
    protected int duracionSegundos;

    /**----------------------------------------------------------------------------------------------------------
     * Constructor con todos los atributos.
     *
     * @param titulo           Título del elemento multimedia.
     * @param duracionSegundos Duración en segundos.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Multimedia(String titulo, int duracionSegundos) {
        this.titulo = titulo;
        this.duracionSegundos = duracionSegundos;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Constructor sobrecargado: crea un elemento multimedia solo con el título.
     * La duración queda en 0 por defecto.
     *
     * @param titulo Título del elemento multimedia.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Multimedia(String titulo) {
        this.titulo = titulo;
        this.duracionSegundos = 0;
    }

    // ----------------------------- Getters y Setters -----------------------------

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getDuracionSegundos() {
        return duracionSegundos;
    }

    public void setDuracionSegundos(int duracionSegundos) {
        this.duracionSegundos = duracionSegundos;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Método abstracto que cada subclase debe implementar para retornar
     * información descriptiva del elemento.
     *
     * @return Cadena con la información del elemento.
     * ----------------------------------------------------------------------------------------------------------
     */
    public abstract String getInfo();
}
