package modelo;


public class BibliotecaMusical {

    private Cancion[] catalogo;       // Arreglo de canciones del catálogo
    private int contadorCatalogo;     // Cantidad actual de canciones
    private int maxCatalogo;          // Capacidad máxima del catálogo

    /**----------------------------------------------------------------------------------------------------------
     * Constructor con capacidad personalizada.
     *
     * @param maxCatalogo Número máximo de canciones en el catálogo.
     * ----------------------------------------------------------------------------------------------------------
     */
    public BibliotecaMusical(int maxCatalogo) {
        this.maxCatalogo = maxCatalogo;
        this.catalogo = new Cancion[maxCatalogo];
        this.contadorCatalogo = 0;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Constructor sobrecargado: capacidad por defecto de 50 canciones.
     * ----------------------------------------------------------------------------------------------------------
     */
    public BibliotecaMusical() {
        this(50);
    }

    //----------------------------------------------------------------------------------------------------------//
    // ----------------------------- Getters --------------------------------------
    //----------------------------------------------------------------------------------------------------------//

    public Cancion[] getCatalogo() {
        return catalogo;
    }

    public int getContadorCatalogo() {
        return contadorCatalogo;
    }

    //----------------------------------------------------------------------------------------------------------//
    // ----------------------------- Métodos principales -------------------------
    //----------------------------------------------------------------------------------------------------------//

    /**----------------------------------------------------------------------------------------------------------
     * Agrega una canción al catálogo de la biblioteca.
     *
     * @param c Canción a agregar.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void agregarCancion(Cancion c) {
        if (contadorCatalogo >= maxCatalogo) {
            System.out.println("El catálogo está lleno. No se pudo agregar la canción.");
            return;
        }
        catalogo[contadorCatalogo] = c;
        contadorCatalogo++;
        System.out.println("Canción agregada exitosamente a la biblioteca.");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Busca canciones cuyo título contenga el fragmento indicado.
     * La búsqueda no es sensible a mayúsculas/minúsculas.
     *
     * @param nombre Fragmento del título a buscar.
     * @return La primera canción que coincida, o null si no se encuentra.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Cancion buscarPorNombre(String nombre) {
        for (int i = 0; i < contadorCatalogo; i++) {
            if (catalogo[i].getTitulo().toLowerCase().contains(nombre.toLowerCase())) {
                return catalogo[i];
            }
        }
        return null; // No se encontró ninguna coincidencia
    }

    /**----------------------------------------------------------------------------------------------------------
     * Lista todas las canciones disponibles en el catálogo de la biblioteca.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void listarCatalogo() {
        if (contadorCatalogo == 0) {
            System.out.println("La biblioteca está vacía.");
            return;
        }
        System.out.println("\n--- LISTA DE CANCIONES EN BIBLIOTECA ---");
        for (int i = 0; i < contadorCatalogo; i++) {
            System.out.println("[" + i + "] " + catalogo[i].getInfo());
        }
        System.out.println("------------------------------------------");
        System.out.println("Total: " + contadorCatalogo + " canciones");
    }
}
