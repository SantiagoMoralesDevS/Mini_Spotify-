package modelo;


public class CuentaSpotify {

    private String usuario;
    private String password;
    private Playlist[] playlists;       // Playlists del usuario
    private int contadorPlaylists;      // Número actual de playlists
    private int maxPlaylists;           // Capacidad máxima de playlists
    private BibliotecaMusical biblioteca; // Biblioteca musical vinculada a la cuenta
    private boolean sesionIniciada;     // Estado de la sesión

    /**----------------------------------------------------------------------------------------------------------
     * Constructor completo de la cuenta de usuario.
     *
     * @param usuario      Nombre de usuario.
     * @param password     Contraseña de acceso.
     * @param maxPlaylists Número máximo de playlists permitidas.
     * ----------------------------------------------------------------------------------------------------------
     */
    public CuentaSpotify(String usuario, String password, int maxPlaylists) {
        this.usuario = usuario;
        this.password = password;
        this.maxPlaylists = maxPlaylists;
        this.playlists = new Playlist[maxPlaylists];
        this.contadorPlaylists = 0;
        this.sesionIniciada = false;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Constructor sobrecargado: capacidad de 10 playlists por defecto.
     *
     * @param usuario  Nombre de usuario.
     * @param password Contraseña de acceso.
     * ----------------------------------------------------------------------------------------------------------
     */
    public CuentaSpotify(String usuario, String password) {
        this(usuario, password, 10);
    }

    //----------------------------------------------------------------------------------------------------------//
    // ----------------------------- Getters y Setters ----------------------------
    //----------------------------------------------------------------------------------------------------------//

    public String getUsuario() {
        return usuario;
    }

    public boolean isSesionIniciada() {
        return sesionIniciada;
    }

    public BibliotecaMusical getBiblioteca() {
        return biblioteca;
    }

    public void setBiblioteca(BibliotecaMusical biblioteca) {
        this.biblioteca = biblioteca;
    }

    public Playlist[] getPlaylists() {
        return playlists;
    }

    public int getContadorPlaylists() {
        return contadorPlaylists;
    }

    //----------------------------------------------------------------------------------------------------------//
    // ----------------------------- Métodos de sesión ----------------------------
    //----------------------------------------------------------------------------------------------------------//

    /**----------------------------------------------------------------------------------------------------------
     * Valida las credenciales del usuario e inicia sesión si son correctas.
     *
     * @param u Nombre de usuario ingresado.
     * @param p Contraseña ingresada.
     * @return true si el inicio de sesión fue exitoso, false en caso contrario.
     * ----------------------------------------------------------------------------------------------------------
     */
    public boolean iniciarSesion(String u, String p) {
        if (this.usuario.equals(u) && this.password.equals(p)) {
            sesionIniciada = true;
            System.out.println("Inicio de sesión exitoso. Bienvenido, " + usuario + ".");
            return true;
        }
        System.out.println("Usuario o contraseña incorrectos.");
        return false;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Cierra la sesión activa del usuario.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void cerrarSesion() {
        sesionIniciada = false;
        System.out.println("Sesión cerrada.");
    }

    //----------------------------------------------------------------------------------------------------------//
    // ----------------------------- Métodos de playlists -------------------------
    //----------------------------------------------------------------------------------------------------------//

    /**----------------------------------------------------------------------------------------------------------
     * Agrega una nueva playlist a la cuenta del usuario.
     *
     * @param p Playlist a agregar.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void agregarPlaylist(Playlist p) {
        if (contadorPlaylists >= maxPlaylists) {
            System.out.println("Se alcanzó el límite de playlists. No se pudo agregar.");
            return;
        }
        playlists[contadorPlaylists] = p;
        contadorPlaylists++;
        System.out.println("Playlist creada correctamente.");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Busca una playlist por nombre (sin distinguir mayúsculas/minúsculas).
     *
     * @param nombre Nombre de la playlist a buscar.
     * @return La playlist encontrada, o null si no existe.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Playlist buscarPlaylist(String nombre) {
        for (int i = 0; i < contadorPlaylists; i++) {
            if (playlists[i].getNombre().equalsIgnoreCase(nombre)) {
                return playlists[i];
            }
        }
        return null;
    }

    /**----------------------------------------------------------------------------------------------------------
     * Agrega una canción a una playlist específica de la cuenta.
     *
     * @param nombrePlaylist Nombre de la playlist destino.
     * @param c              Canción a agregar.
     * ----------------------------------------------------------------------------------------------------------
     */
    public void agregarCancionAPlaylist(String nombrePlaylist, Cancion c) {
        Playlist playlist = buscarPlaylist(nombrePlaylist);
        if (playlist == null) {
            System.out.println("No se encontró la playlist \"" + nombrePlaylist + "\".");
            return;
        }
        playlist.agregarCancion(c);
        System.out.println("Canción agregada correctamente a la playlist.");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Reproduce una canción de una playlist usando su índice.
     * Hace uso polimórfico de la interfaz Reproducible.
     *
     * @param nombrePlaylist Nombre de la playlist.
     * @param indexCancion   Índice de la canción dentro de la playlist.
     * @return La canción reproducida, o null si no se encontró.
     * ----------------------------------------------------------------------------------------------------------
     */
    public Cancion reproducir(String nombrePlaylist, int indexCancion) {
        Playlist playlist = buscarPlaylist(nombrePlaylist);
        if (playlist == null) {
            System.out.println("No se encontró la playlist \"" + nombrePlaylist + "\".");
            return null;
        }
        return playlist.reproducirCancion(indexCancion);
    }
}
