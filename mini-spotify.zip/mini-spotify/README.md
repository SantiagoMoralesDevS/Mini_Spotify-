# Mini-Spotify — Ejercicio Avanzado para entrega de modulo

//------------------------------------------------------------------------------------------------------------------------------------------------------//
## Descripción
Simulación básica de una plataforma de música tipo Spotify implementada en Java,
aplicando los principios de la Programación Orientada a Objetos.
//------------------------------------------------------------------------------------------------------------------------------------------------------//

## Conceptos aplicados
- **Herencia**: `Cancion` hereda de `Multimedia`.
- **Interfaces y polimorfismo**: `Cancion` implementa `Reproducible`; se usa `Reproducible` como tipo en `SpotifyApp`.
- **Encapsulamiento**: Atributos privados/protegidos con getters y setters.
- **Sobrecarga**: Múltiples constructores en `Multimedia`, `Cancion`, `Playlist`, `BibliotecaMusical` y `CuentaSpotify`; método `agregarCancion` sobrecargado en `Playlist`.
- **Agregación**: `Playlist` contiene objetos `Cancion`; `CuentaSpotify` contiene `Playlist` y `BibliotecaMusical`.
- **Abstracción**: Clase abstracta `Multimedia` con método abstracto `getInfo()`.
//------------------------------------------------------------------------------------------------------------------------------------------------------//

## Estructura del proyecto

mini-spotify/
└── src/
    ├── modelo/
    │   ├── Reproducible.java
    │   ├── Multimedia.java
    │   ├── Cancion.java
    │   ├── Playlist.java
    │   ├── BibliotecaMusical.java
    │   └── CuentaSpotify.java
    └── app/
        └── SpotifyApp.java
```

## Cómo compilar y ejecutar

### Opción — Desde la terminal (javac)
```bash
# Desde la carpeta raíz del proyecto
javac -d out src/modelo/*.java src/app/SpotifyApp.java
java -cp out app.SpotifyApp
```


## Credenciales de prueba
- **Usuario**: `enrique`
- **Contraseña**: `1234`

## Canciones de prueba precargadas
| Título            | Artista         | Duración |
|-------------------|-----------------|----------|
| Shape of You      | Ed Sheeran      | 240s     |
| Believer          | Imagine Dragons | 210s     |
| Thunderstruck     | AC/DC           | 290s     |
| Someone Like You  | Adele           | 300s     |
